

// Initialize the grammar
const rg = RiTa.grammar(grammarRules);

const outputElement = document.getElementById('output');
const button = document.getElementById('generate-btn');

function generate() {
  const result = rg.expand();
  outputElement.innerText = result;
}

button.addEventListener('click', generate);

// Generate initial story
generate();