const grammarRules = {
  "start": "$intro $noun_phrase $verb_phrase.",
  "intro": "Once | Suddenly | In a distant land | Yesterday",
  "noun_phrase": "$adj $noun",
  "verb_phrase": "$verb $adj $noun",
  "adj": "a neon | the lonely | an ancient | a whispering | the caffeinated",
  "noun": "forest | android | cloud | philosopher | bicycle",
  "verb": "discovered | transformed into | sang to | escaped from"
};